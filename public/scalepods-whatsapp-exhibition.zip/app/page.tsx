import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, KeyRound, Workflow, Shield } from "lucide-react"
import { HeroSection } from "@/components/landing/hero-section"
import { RippleDemo } from "@/components/landing/ripple-demo"
import dynamic from "next/dynamic"

const PixelBlast = dynamic(() => import("@/components/landing/pixel-blast").then((m) => m.PixelBlast), {
  ssr: false,
  loading: () => null,
})

export default function LandingPage() {
  // Locally n8n-inspired accent without global override:
  // Inside this page, we override the design token --color-accent and --color-primary for a vibrant green.
  return (
    <main
      className="min-h-svh bg-background text-foreground"
      style={
        {
          // n8n-like vibrant green accent via tokens
          // oklch values chosen for good contrast in dark mode
          ["--accent" as any]: "oklch(0.77 0.18 145)", // green accent
          ["--primary" as any]: "oklch(0.98 0 0)", // near-white for headings
          ["--primary-foreground" as any]: "oklch(0.2 0 0)",
        } as React.CSSProperties
      }
    >
      <header className="border-b">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <img src="/placeholder-logo.jpg" alt="Scalepods Logo" className="h-6 w-6" />
            <span className="font-semibold">Scalepods</span>
          </div>
          <nav className="hidden gap-6 text-sm md:flex">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link href="/setup-credentials" className="text-muted-foreground hover:text-foreground">
              Credentials
            </Link>
            <Link href="/manage-campaigns" className="text-muted-foreground hover:text-foreground">
              Campaigns
            </Link>
            <a
              href="https://docs.n8n.io/"
              target="_blank"
              rel="noreferrer"
              className="text-muted-foreground hover:text-foreground"
            >
              Docs
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/sign-in">
              <Button variant="default">Sign In</Button>
            </Link>
            <Link href="/setup-credentials">
              <Button variant="outline" className="bg-transparent">
                Get Started
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button>Open Dashboard</Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="relative">
          {/* PixelBlast background animation (ReactBits-inspired) */}
          <div className="pointer-events-none absolute inset-0 -z-10">
            <PixelBlast
              variant="circle"
              pixelSize={6}
              color="#22c55e" // n8n-inspired green that fits the page accent
              patternScale={3}
              patternDensity={1.2}
              pixelSizeJitter={0.5}
              enableRipples
              rippleSpeed={0.4}
              rippleThickness={0.12}
              rippleIntensityScale={1.5}
              liquid
              liquidStrength={0.12}
              liquidRadius={1.2}
              liquidWobbleSpeed={5}
              speed={0.6}
              edgeFade={0.25}
              transparent
            />
          </div>
          {/* Subtle radial gradient to complement PixelBlast (low opacity for elegance) */}
          <div
            className="pointer-events-none absolute inset-0 -z-10 opacity-50"
            aria-hidden="true"
            style={{
              background:
                "radial-gradient(600px circle at 20% 10%, rgba(34,197,94,0.15), transparent 60%), radial-gradient(600px circle at 80% 20%, rgba(59,130,246,0.10), transparent 60%)",
            }}
          />
          <HeroSection />
        </div>

        <div className="relative mx-auto mt-10 md:mt-14 max-w-3xl overflow-hidden rounded-xl border bg-card/50 p-8 md:p-10">
          {/* Decorative animated gradient rule */}
          <div
            className="pointer-events-none absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-accent/60 to-transparent motion-safe:animate-pulse"
            aria-hidden="true"
          />
          {/* Existing glow kept but softened */}
          <div
            className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/20 blur-3xl motion-safe:animate-pulse"
            aria-hidden="true"
          />

          <Badge className="bg-accent text-accent-foreground">Get Started</Badge>
          <h2 className="mt-4 text-pretty text-2xl font-semibold tracking-tight md:text-3xl">
            Start connecting providers in minutes
          </h2>
          <p className="mt-2 text-muted-foreground leading-relaxed">
            Securely store credentials and orchestrate campaigns with a clean, reliable workflow.
          </p>

          {/* Single CTA to reduce duplication on the page */}
          <div className="mt-6">
            <Link href="/sign-in">
              <Button className="font-medium">Get Started</Button>
            </Link>
          </div>
        </div>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          <Card className="feature-card">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <KeyRound className="h-5 w-5 text-accent" />
                <h3 className="font-medium">Secure Storage</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                Credentials are encrypted before storage and protected with strict per‑user RLS policies.
              </p>
            </CardContent>
          </Card>
          <Card className="feature-card">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <Workflow className="h-5 w-5 text-accent" />
                <h3 className="font-medium">n8n‑Inspired UX</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                Familiar, clean UI built with shadcn components for clarity and speed.
              </p>
            </CardContent>
          </Card>
          <Card className="feature-card">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-accent" />
                <h3 className="font-medium">RBAC Ready</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                Enforced access controls ensure only you can read or update your services.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16">
          <RippleDemo />
        </div>

        <div className="mt-16 rounded-lg border p-6">
          <h2 className="text-lg font-semibold">Credential Status Snapshot</h2>
          <ul className="mt-4 grid gap-3 text-sm md:grid-cols-2">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              Store Google, Gmail, Calendar, Groq AI, and WABA keys per user
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              One‑click configure via Setup Credentials
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              Encrypted at write, safe by default with RLS
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-accent" />
              Dashboard metrics for connected services and campaigns
            </li>
          </ul>
        </div>
      </section>

      <footer className="border-t">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-6 text-sm text-muted-foreground">
          <span>© {new Date().getFullYear()} Scalepods</span>
          <div className="flex gap-4">
            <a href="https://docs.n8n.io/" target="_blank" rel="noreferrer" className="hover:text-foreground">
              n8n Docs
            </a>
            <Link href="/setup-credentials" className="hover:text-foreground">
              Quick Start
            </Link>
          </div>
        </div>
      </footer>
    </main>
  )
}
