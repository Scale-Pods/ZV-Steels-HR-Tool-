import { NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"

export async function POST() {
  try {
    const supabase = await createServerClient()
    const { data: userRes } = await supabase.auth.getUser()
    const userId = userRes.user?.id
    if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const { data, error } = await supabase
      .from("campaigns")
      .insert({
        user_id: userId,
        name: `Exhibition Campaign ${new Date().toLocaleString()}`,
        created_at: new Date().toISOString(),
      })
      .select("*")
      .single()

    if (error) throw error
    return NextResponse.json({ ok: true, campaign: data })
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? "Unknown error" }, { status: 500 })
  }
}
