import { NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase/server"
import { encryptJSON } from "@/lib/crypto"

export async function GET() {
  try {
    const supabase = await createServerClient()
    const { data: userRes } = await supabase.auth.getUser()
    const userId = userRes.user?.id
    if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const { data, error } = await supabase.from("user_integrations").select("service, connected").eq("user_id", userId)

    if (error) throw error

    const map: Record<string, boolean> = {}
    for (const row of data ?? []) {
      map[row.service] = !!row.connected
    }
    return NextResponse.json({ services: map })
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? "Unknown error" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { service: string; credentials: Record<string, string> }
    const supabase = await createServerClient()
    const { data: userRes } = await supabase.auth.getUser()
    const userId = userRes.user?.id
    if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    // Encrypt before storing
    const encrypted = await encryptJSON(body.credentials)

    const { error } = await supabase.from("user_integrations").upsert(
      {
        user_id: userId,
        service: body.service,
        credentials: encrypted as any,
        connected: true,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id,service" },
    )

    if (error) throw error

    return NextResponse.json({ ok: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message ?? "Unknown error" }, { status: 500 })
  }
}
