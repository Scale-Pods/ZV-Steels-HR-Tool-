import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { createServerClient } from "@supabase/ssr"
import { encryptJSON } from "@/lib/crypto"

function getSupabaseServer() {
  const cookieStore = cookies()
  const supabase = createServerClient(process.env.SUPABASE_URL!, process.env.SUPABASE_ANON_KEY!, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value
      },
      set(name: string, value: string, options: any) {
        cookieStore.set({ name, value, ...options })
      },
      remove(name: string, options: any) {
        cookieStore.set({ name, value: "", ...options })
      },
    },
  })
  return supabase
}

export async function GET() {
  try {
    const supabase = getSupabaseServer()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()
    if (userError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data, error } = await supabase
      .from("node_credentials")
      .select("id,node_key,label,created_at,updated_at")
      .eq("user_id", user.id)
      .order("node_key", { ascending: true })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Do not return secrets. Only metadata that shows something is stored.
    const safe = (data ?? []).map((row) => ({
      id: row.id,
      node_key: row.node_key,
      label: row.label,
      created_at: row.created_at,
      updated_at: row.updated_at,
      stored: true,
    }))

    return NextResponse.json({ data: safe })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Server error" }, { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const supabase = getSupabaseServer()
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser()
    if (userError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json().catch(() => null)
    const { nodeKey, label, credentials } = body || {}

    if (!nodeKey || typeof nodeKey !== "string") {
      return NextResponse.json({ error: "nodeKey (string) is required" }, { status: 400 })
    }
    if (!credentials || typeof credentials !== "object") {
      return NextResponse.json({ error: "credentials (object) is required" }, { status: 400 })
    }

    // Encrypt credentials JSON using app's crypto helper
    const encrypted = encryptJSON(credentials)

    // Upsert by (user_id, node_key)
    const { data, error } = await supabase
      .from("node_credentials")
      .upsert(
        {
          user_id: user.id,
          node_key: nodeKey,
          label: label ?? null,
          credentials_encrypted: encrypted,
        },
        { onConflict: "user_id,node_key" },
      )
      .select("id,node_key,label,created_at,updated_at")
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ data, stored: true })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Server error" }, { status: 500 })
  }
}
