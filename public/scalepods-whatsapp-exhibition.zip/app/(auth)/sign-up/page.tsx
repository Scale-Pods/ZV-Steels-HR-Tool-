"use client"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { SignUpForm } from "@/components/auth/sign-up-form"

export default function SignUpPage() {
  return (
    <div className="min-h-svh grid place-items-center px-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="mx-auto">
            <Image src="/placeholder-logo.svg" alt="Scalepods logo" width={36} height={36} />
          </div>
          <CardTitle className="text-pretty">Create your account</CardTitle>
          <CardDescription>Start automating your WhatsApp campaigns.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignUpForm />
        </CardContent>
      </Card>
    </div>
  )
}
