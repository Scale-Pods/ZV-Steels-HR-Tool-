"use client"

import Link from "next/link"
import Image from "next/image"
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import { Home, KeyRound, Settings2, HelpCircle, Workflow, Sparkles, Zap } from "lucide-react"
import type { ReactNode } from "react"
import { PageHeader } from "@/components/page-header"

function NavItems() {
  const pathname = usePathname()
  const items = [
    { 
      href: "/dashboard", 
      label: "Dashboard", 
      icon: <Home className="size-4" />,
      description: "Overview & Analytics"
    },
    { 
      href: "/setup-credentials", 
      label: "Credentials", 
      icon: <KeyRound className="size-4" />,
      description: "API Configuration"
    },
    { 
      href: "/manage-campaigns", 
      label: "Campaigns", 
      icon: <Workflow className="size-4" />,
      description: "Create & Manage"
    },
  ]

  const externalItems = [
    { 
      href: "https://docs.n8n.io/", 
      label: "Documentation", 
      icon: <HelpCircle className="size-4" />,
      external: true 
    },
  ]

  return (
    <>
      <SidebarMenu>
        {items.map((item) => (
          <SidebarMenuItem key={item.href}>
            <Link href={item.href} className="w-full">
              <SidebarMenuButton 
                asChild 
                isActive={pathname === item.href}
                className="w-full"
              >
                <span className="flex items-center gap-3 w-full">
                  <span className={`${pathname === item.href ? 'text-primary' : 'text-muted-foreground'}`}>
                    {item.icon}
                  </span>
                  <span className="flex-1">
                    <div className="font-medium text-sm">{item.label}</div>
                    <div className="text-xs text-muted-foreground group-data-[state=collapsed]:hidden">
                      {item.description}
                    </div>
                  </span>
                </span>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
      
      <SidebarSeparator className="my-2" />
      
      <SidebarMenu>
        {externalItems.map((item) => (
          <SidebarMenuItem key={item.href}>
            <Link href={item.href} target="_blank" rel="noopener noreferrer">
              <SidebarMenuButton asChild isActive={false}>
                <span className="flex items-center gap-3">
                  <span className="text-muted-foreground">{item.icon}</span>
                  <span>{item.label}</span>
                </span>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </>
  )
}

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <SidebarProvider>
      <Sidebar collapsible="icon" className="border-r">
        <SidebarHeader className="border-b">
          <div className="flex items-center gap-3 px-3 py-3">
            <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600">
              <Zap className="size-4 text-white" />
            </div>
            <div className="flex flex-col group-data-[state=collapsed]:hidden">
              <span className="font-bold text-base">Scalepods</span>
              <span className="text-xs text-muted-foreground">WhatsApp Automation</span>
            </div>
          </div>
        </SidebarHeader>
        
        <SidebarContent className="px-2">
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs uppercase tracking-wider text-muted-foreground px-2 mb-2">
              Main Menu
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <NavItems />
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        
        <SidebarFooter className="border-t p-2">
          <Link href="/setup-credentials" className="block">
            <Button 
              variant="outline" 
              className="w-full justify-start gap-2 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-200 dark:border-purple-800 hover:from-purple-100 hover:to-pink-100 dark:hover:from-purple-900 dark:hover:to-pink-900"
            >
              <Sparkles className="size-4 text-purple-600 dark:text-purple-400" />
              <span className="group-data-[state=collapsed]:hidden">Quick Setup</span>
            </Button>
          </Link>
        </SidebarFooter>
        
        <SidebarRail />
      </Sidebar>
      
      <SidebarInset className="min-h-svh bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
        <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-14 items-center gap-3 px-4">
            <SidebarTrigger className="hover:bg-accent" />
            <PageHeader />
          </div>
        </header>
        
        <main className="p-6">
          {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  )
}
