"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { 
  Loader2, 
  Send, 
  Workflow, 
  Plus, 
  Zap, 
  MessageSquare,
  Bot,
  FileSpreadsheet,
  ArrowRight,
  CheckCircle2,
  Rocket,
  Bell,
  ExternalLink
} from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function ManageCampaignsPage() {
  const [creating, setCreating] = useState(false)
  const { toast } = useToast()

  const createCampaign = async () => {
    setCreating(true)
    try {
      const res = await fetch("/api/campaigns", { method: "POST" })
      if (!res.ok) throw new Error((await res.json()).error ?? "Failed to create campaign")
      toast({ 
        title: "Campaign created successfully! 🎉", 
        description: "Your new campaign sheet is ready and the workflow has been activated.",
      })
    } catch (e: any) {
      toast({ 
        title: "Error creating campaign", 
        description: e.message, 
        variant: "destructive" 
      })
    } finally {
      setCreating(false)
    }
  }

  const features = [
    {
      icon: <FileSpreadsheet className="size-5" />,
      title: "Automated Sheet Setup",
      description: "Each campaign gets its own Google Sheet for organized data management"
    },
    {
      icon: <Workflow className="size-5" />,
      title: "Instant Workflow Activation",
      description: "Your n8n workflow activates automatically when you create a campaign"
    },
    {
      icon: <MessageSquare className="size-5" />,
      title: "WhatsApp Integration",
      description: "Send automated messages through WhatsApp Business API"
    },
    {
      icon: <Bot className="size-5" />,
      title: "AI-Powered Responses",
      description: "Groq AI generates intelligent, context-aware message responses"
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center size-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-600">
            <Workflow className="size-5 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Campaign Management</h1>
            <p className="text-muted-foreground">Create and manage your WhatsApp exhibition campaigns</p>
          </div>
        </div>
      </div>

      {/* Quick Start Alert */}
      <Alert className="border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 dark:border-blue-900">
        <Rocket className="size-4 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="font-semibold text-blue-900 dark:text-blue-100">
          Ready to Launch Your First Campaign?
        </AlertTitle>
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          Make sure all your API credentials are configured before creating a campaign. Each campaign will automatically set up a dedicated Google Sheet and activate your automation workflow.
        </AlertDescription>
      </Alert>

      {/* Main Action Cards */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Create Campaign Card */}
        <Card className="group relative overflow-hidden transition-all hover:shadow-xl border-2">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          
          <CardHeader className="relative">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center justify-center size-14 rounded-2xl bg-gradient-to-br from-purple-600 to-pink-600 shadow-lg shadow-purple-500/30">
                <Plus className="size-7 text-white" />
              </div>
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-3 py-1 rounded-full">
                <Zap className="size-3" />
                Quick Setup
              </div>
            </div>
            <CardTitle className="text-2xl">Launch a New Campaign</CardTitle>
            <CardDescription className="text-base leading-relaxed">
              Instantly create a new campaign with automated Google Sheet setup and workflow activation. Your campaign will be ready to receive and process WhatsApp messages in seconds.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="relative space-y-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-green-600" />
                <span>Creates dedicated Google Sheet</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-green-600" />
                <span>Activates n8n workflow automatically</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-green-600" />
                <span>Configures WhatsApp integration</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-green-600" />
                <span>Sets up AI response system</span>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="relative">
            <Button 
              onClick={createCampaign} 
              disabled={creating} 
              size="lg"
              className="w-full gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg shadow-purple-500/30"
            >
              {creating ? (
                <>
                  <Loader2 className="size-5 animate-spin" />
                  Creating Campaign...
                </>
              ) : (
                <>
                  <Plus className="size-5" />
                  Create New Campaign
                  <ArrowRight className="size-4 ml-auto" />
                </>
              )}
            </Button>
          </CardFooter>
        </Card>

        {/* Telegram Bot Card */}
        <Card className="group relative overflow-hidden transition-all hover:shadow-xl border-2">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          
          <CardHeader className="relative">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center justify-center size-14 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-600 shadow-lg shadow-blue-500/30">
                <Bell className="size-7 text-white" />
              </div>
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-3 py-1 rounded-full">
                <Send className="size-3" />
                Real-time
              </div>
            </div>
            <CardTitle className="text-2xl">Get Real-Time Updates</CardTitle>
            <CardDescription className="text-base leading-relaxed">
              Stay informed about your campaign activities with instant notifications. Create a personal Telegram bot using BotFather to receive live updates for every message and interaction.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="relative space-y-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-blue-600" />
                <span>Instant message notifications</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-blue-600" />
                <span>Campaign activity logs</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-blue-600" />
                <span>Error alerts and warnings</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-blue-600" />
                <span>Performance metrics</span>
              </div>
            </div>

            <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-900">
              <Bot className="size-4 text-blue-600 dark:text-blue-400" />
              <AlertTitle className="text-sm font-semibold">How to Set Up</AlertTitle>
              <AlertDescription className="text-xs mt-1">
                1. Click the button below to open BotFather
                <br />
                2. Send /newbot and follow the instructions
                <br />
                3. Copy your bot token and add it to credentials
              </AlertDescription>
            </Alert>
          </CardContent>
          
          <CardFooter className="relative">
            <Button 
              asChild
              size="lg"
              variant="outline"
              className="w-full gap-2 border-2 hover:bg-blue-50 dark:hover:bg-blue-950 group"
            >
              <a
                href="https://t.me/BotFather"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Send className="size-5" />
                Create Bot with BotFather
                <ExternalLink className="size-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Features Grid */}
      <div className="space-y-3">
        <h2 className="text-xl font-semibold">Campaign Features</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-md transition-all">
              <CardHeader>
                <div className="flex items-center justify-center size-10 rounded-lg bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 group-hover:from-purple-100 group-hover:to-pink-100 dark:group-hover:from-purple-900 dark:group-hover:to-pink-900 transition-all mb-3">
                  <span className="text-muted-foreground group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
                    {feature.icon}
                  </span>
                </div>
                <CardTitle className="text-base">{feature.title}</CardTitle>
                <CardDescription className="text-sm">
                  {feature.description}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>

      {/* Workflow Info Card */}
      <Card className="border-dashed">
        <CardHeader>
          <div className="flex items-start gap-3">
            <div className="flex items-center justify-center size-10 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600">
              <Workflow className="size-5 text-white" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-lg">How It Works</CardTitle>
              <CardDescription className="mt-1">
                Your WhatsApp exhibition automation workflow powered by n8n
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center size-8 rounded-lg bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-400 font-bold text-sm">
                  1
                </div>
                <h3 className="font-semibold text-sm">Receive Messages</h3>
              </div>
              <p className="text-sm text-muted-foreground pl-10">
                WhatsApp Business API captures incoming messages from exhibition visitors
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center size-8 rounded-lg bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 font-bold text-sm">
                  2
                </div>
                <h3 className="font-semibold text-sm">Process with AI</h3>
              </div>
              <p className="text-sm text-muted-foreground pl-10">
                Groq AI analyzes messages and generates intelligent, contextual responses
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center size-8 rounded-lg bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 font-bold text-sm">
                  3
                </div>
                <h3 className="font-semibold text-sm">Log & Notify</h3>
              </div>
              <p className="text-sm text-muted-foreground pl-10">
                Data saves to Google Sheets and notifications sent via Telegram and Gmail
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Prerequisites Card */}
      <Card className="bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950 dark:to-orange-950 border-amber-200 dark:border-amber-900">
        <CardHeader>
          <div className="flex items-start gap-3">
            <div className="flex items-center justify-center size-10 rounded-lg bg-amber-500">
              <Zap className="size-5 text-white" />
            </div>
            <div className="flex-1">
              <CardTitle className="text-lg">Before You Start</CardTitle>
              <CardDescription className="mt-1">
                Make sure you have completed these prerequisites
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-white dark:bg-slate-900 rounded-lg">
              <CheckCircle2 className="size-5 text-amber-600 dark:text-amber-400 mt-0.5" />
              <div>
                <h4 className="font-medium text-sm">Configure All API Credentials</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Ensure Google Sheets, Gmail, Calendar, Groq AI, and WABA are all connected
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-3 bg-white dark:bg-slate-900 rounded-lg">
              <CheckCircle2 className="size-5 text-amber-600 dark:text-amber-400 mt-0.5" />
              <div>
                <h4 className="font-medium text-sm">WhatsApp Business API Setup</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Your WhatsApp Business account should be verified and have an active phone number
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3 p-3 bg-white dark:bg-slate-900 rounded-lg">
              <CheckCircle2 className="size-5 text-amber-600 dark:text-amber-400 mt-0.5" />
              <div>
                <h4 className="font-medium text-sm">n8n Workflow Ready</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Your n8n instance should be running and accessible for workflow activation
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" asChild className="gap-2">
            <a href="/setup-credentials">
              <ArrowRight className="size-4" />
              Go to Credentials Setup
            </a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
