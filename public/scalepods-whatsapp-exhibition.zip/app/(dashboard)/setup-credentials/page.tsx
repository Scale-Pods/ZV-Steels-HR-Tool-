"use client"

import type React from "react"

import useSWR from "swr"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ConfigureSheet } from "@/components/credentials/configure-sheet"
import { Calendar, FileSpreadsheet, Mail, MessageSquare, Bot } from "lucide-react"

type ServiceKey = "google_sheets" | "gmail" | "google_calendar" | "groq_ai" | "waba"

const services: {
  key: ServiceKey
  name: string
  icon: React.ReactNode
  docs: string
  fields: { name: string; label: string; type: "password" | "text" }[]
}[] = [
  {
    key: "google_sheets",
    name: "Google Sheets",
    icon: <FileSpreadsheet className="size-5" />,
    docs: "https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.googlesheets/",
    fields: [
      { name: "client_id", label: "Client ID", type: "password" },
      { name: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    key: "gmail",
    name: "Gmail",
    icon: <Mail className="size-5" />,
    docs: "https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.gmail/",
    fields: [
      { name: "client_id", label: "Client ID", type: "password" },
      { name: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    key: "google_calendar",
    name: "Google Calendar",
    icon: <Calendar className="size-5" />,
    docs: "https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.googlecalendar/",
    fields: [
      { name: "client_id", label: "Client ID", type: "password" },
      { name: "client_secret", label: "Client Secret", type: "password" },
    ],
  },
  {
    key: "groq_ai",
    name: "Groq AI",
    icon: <Bot className="size-5" />,
    docs: "https://docs.n8n.io/integrations/builtin/credentials/groq/",
    fields: [{ name: "api_key", label: "API Key", type: "password" }],
  },
  {
    key: "waba",
    name: "WhatsApp Business API",
    icon: <MessageSquare className="size-5" />,
    docs: "https://docs.n8n.io/integrations/builtin/credentials/whatsapp/#using-oauth2",
    fields: [
      { name: "phone_number_id", label: "Phone Number ID", type: "text" },
      { name: "access_token", label: "Permanent Access Token", type: "password" },
    ],
  },
]

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function SetupCredentialsPage() {
  const [openKey, setOpenKey] = useState<ServiceKey | null>(null)
  const [connected, setConnected] = useState<Record<ServiceKey, boolean>>({
    google_sheets: false,
    gmail: false,
    google_calendar: false,
    groq_ai: false,
    waba: false,
  })

  const { data } = useSWR<{ services: Record<string, boolean> }>("/api/credentials", fetcher)

  useEffect(() => {
    if (data?.services) {
      setConnected((prev) => ({ ...prev, ...(data.services as any) }))
    }
  }, [data])

  const onSaved = (key: ServiceKey) => {
    setConnected((prev) => ({ ...prev, [key]: true }))
    setOpenKey(null)
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {services.map((svc) => {
        const isConnected = connected[svc.key]
        return (
          <Card key={svc.key} className="flex flex-col">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-pretty">
                  {svc.icon}
                  {svc.name}
                </CardTitle>
                <Badge
                  variant={isConnected ? "default" : "destructive"}
                  className={isConnected ? "bg-green-600 text-white" : "bg-red-600 text-white"}
                >
                  {isConnected ? "Connected" : "Not Connected"}
                </Badge>
              </div>
              <CardDescription>Connect {svc.name} to enable the n8n workflow.</CardDescription>
            </CardHeader>
            <CardContent className="flex-1" />
            <CardFooter className="justify-end">
              <Button onClick={() => setOpenKey(svc.key)}>Configure</Button>
            </CardFooter>
            <ConfigureSheet
              open={openKey === svc.key}
              onOpenChange={(o) => setOpenKey(o ? svc.key : null)}
              serviceKey={svc.key}
              serviceName={svc.name}
              docsUrl={svc.docs}
              fields={svc.fields}
              onSaved={() => onSaved(svc.key)}
            />
          </Card>
        )
      })}
    </div>
  )
}
