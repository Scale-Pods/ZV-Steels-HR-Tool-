"use client"

import { useEffect } from "react"
import gsap from "gsap"
import { Badge } from "@/components/ui/badge"

export function HeroSection() {
  useEffect(() => {
    // Basic entrance animations
    const tl = gsap.timeline()
    tl.from(".hero-badge", { opacity: 0, y: 8, duration: 0.4, ease: "power2.out" })
      .from(".hero-title", { opacity: 0, y: 14, duration: 0.5, ease: "power2.out" }, "-=0.1")
      .from(".hero-subtitle", { opacity: 0, y: 12, duration: 0.5, ease: "power2.out" }, "-=0.2")

    // Subtle pop-in for feature cards (if present on the page)
    gsap.from(".feature-card", {
      opacity: 0,
      y: 12,
      duration: 0.5,
      stagger: 0.08,
      delay: 0.15,
      ease: "power2.out",
    })
  }, [])

  return (
    <div className="max-w-3xl">
      <Badge className="hero-badge bg-accent text-accent-foreground">WhatsApp Automation</Badge>
      <h1 className="hero-title mt-4 text-balance text-4xl font-semibold tracking-tight md:text-5xl">
        Build reliable, n8n‑style automations for WhatsApp and beyond
      </h1>
      <p className="hero-subtitle mt-3 text-pretty text-muted-foreground leading-relaxed">
        Connect providers, store credentials securely, and orchestrate campaigns with confidence. Your data stays
        encrypted, policies enforced, and workflows just work.
      </p>
    </div>
  )
}
