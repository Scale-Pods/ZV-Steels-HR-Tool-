"use client"

import { Canvas, useFrame } from "@react-three/fiber"
import { useMemo, useRef } from "react"
import * as THREE from "three"

type PixelBlastProps = {
  variant?: "circle" | "square"
  pixelSize?: number
  color?: string
  patternScale?: number
  patternDensity?: number
  pixelSizeJitter?: number
  enableRipples?: boolean
  rippleSpeed?: number
  rippleThickness?: number
  rippleIntensityScale?: number
  liquid?: boolean
  liquidStrength?: number
  liquidRadius?: number
  liquidWobbleSpeed?: number
  speed?: number
  edgeFade?: number
  transparent?: boolean
  className?: string
}

function PixelBlastMaterial({
  color = "hsl(var(--accent))",
  variant = "circle",
  pixelSize = 6,
  patternScale = 3,
  patternDensity = 1.2,
  pixelSizeJitter = 0.5,
  enableRipples = true,
  rippleSpeed = 0.4,
  rippleThickness = 0.12,
  rippleIntensityScale = 1.5,
  liquid = true,
  liquidStrength = 0.12,
  liquidRadius = 1.2,
  liquidWobbleSpeed = 5,
  speed = 0.6,
  edgeFade = 0.25,
  transparent = true,
}: PixelBlastProps) {
  const matRef = useRef<THREE.ShaderMaterial>(null)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uColor: { value: new THREE.Color(color) },
      uAlpha: { value: transparent ? 0.18 : 1.0 },
      uVariant: { value: variant === "circle" ? 1.0 : 0.0 },
      uPixel: { value: pixelSize },
      uPatternScale: { value: patternScale },
      uPatternDensity: { value: patternDensity },
      uPixelJitter: { value: pixelSizeJitter },
      uRipplesEnabled: { value: enableRipples ? 1.0 : 0.0 },
      uRippleSpeed: { value: rippleSpeed },
      uRippleThickness: { value: rippleThickness },
      uRippleIntensity: { value: rippleIntensityScale },
      uLiquid: { value: liquid ? 1.0 : 0.0 },
      uLiquidStrength: { value: liquidStrength },
      uLiquidRadius: { value: liquidRadius },
      uLiquidSpeed: { value: liquidWobbleSpeed },
      uSpeed: { value: speed },
      uEdgeFade: { value: edgeFade },
      uResolution: { value: new THREE.Vector2(1, 1) },
    }),
    [
      color,
      variant,
      pixelSize,
      patternScale,
      patternDensity,
      pixelSizeJitter,
      enableRipples,
      rippleSpeed,
      rippleThickness,
      rippleIntensityScale,
      liquid,
      liquidStrength,
      liquidRadius,
      liquidWobbleSpeed,
      speed,
      edgeFade,
      transparent,
    ],
  )

  useFrame((state) => {
    if (!matRef.current) return
    matRef.current.uniforms.uTime.value = state.clock.getElapsedTime()
    const { width, height } = state.size
    matRef.current.uniforms.uResolution.value.set(width, height)
  })

  const fragmentShader = /* glsl */ `
    precision highp float;

    uniform float uTime;
    uniform vec3  uColor;
    uniform float uAlpha;
    uniform float uVariant;
    uniform float uPixel;
    uniform float uPatternScale;
    uniform float uPatternDensity;
    uniform float uPixelJitter;

    uniform float uRipplesEnabled;
    uniform float uRippleSpeed;
    uniform float uRippleThickness;
    uniform float uRippleIntensity;

    uniform float uLiquid;
    uniform float uLiquidStrength;
    uniform float uLiquidRadius;
    uniform float uLiquidSpeed;

    uniform float uSpeed;
    uniform float uEdgeFade;
    uniform vec2  uResolution;

    varying vec2 vUv;

    // simple hash / noise helpers
    float hash(vec2 p) {
      p = fract(p * vec2(123.34, 345.45));
      p += dot(p, p + 34.345);
      return fract(p.x * p.y);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      float a = hash(i);
      float b = hash(i + vec2(1.0, 0.0));
      float c = hash(i + vec2(0.0, 1.0));
      float d = hash(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    void main() {
      vec2 uv = vUv;

      // liquid warp
      if (uLiquid > 0.5) {
        float t = uTime * uLiquidSpeed * 0.1;
        vec2 warp = vec2(
          noise(uv * uLiquidRadius + t) - 0.5,
          noise(uv.yx * uLiquidRadius - t) - 0.5
        );
        uv += warp * uLiquidStrength;
      }

      // pixel grid
      float px = max(uPixel, 1.0);
      vec2 grid = floor(uv * uPatternScale * uPatternDensity * 100.0 / px);
      float jitter = (noise(grid) - 0.5) * uPixelJitter;
      vec2 cellUv = fract(uv * uPatternScale * (uPatternDensity + jitter)) - 0.5;
      float dist = length(cellUv * 2.0);

      // shape: circle or square
      float shapeMask = (uVariant > 0.5)
        ? smoothstep(0.5, 0.45, dist)
        : smoothstep(0.5, 0.45, max(abs(cellUv.x), abs(cellUv.y)));

      // ripples from center
      float ripples = 1.0;
      if (uRipplesEnabled > 0.5) {
        float d = distance(uv, vec2(0.5));
        float wave = 0.5 + 0.5 * sin((d * (10.0 / max(uRippleThickness, 0.02))) - uTime * (2.0 * uRippleSpeed + uSpeed));
        ripples = mix(1.0, wave, clamp(uRippleIntensity, 0.0, 2.0));
      }

      // edge fade
      float edge = distance(uv, vec2(0.5));
      float fade = smoothstep(1.0, uEdgeFade, edge);

      vec3 col = uColor;
      float alpha = uAlpha * shapeMask * ripples * (1.0 - fade);

      gl_FragColor = vec4(col, alpha);
    }
  `

  const vertexShader = /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position, 1.0);
    }
  `

  return (
    <shaderMaterial
      ref={matRef}
      uniforms={uniforms}
      fragmentShader={fragmentShader}
      vertexShader={vertexShader}
      transparent
      depthWrite={false}
    />
  )
}

export function PixelBlast(props: PixelBlastProps) {
  return (
    <div className={props.className} style={{ width: "100%", height: "100%", position: "relative" }}>
      <Canvas dpr={[1, 2]} gl={{ alpha: true, antialias: true }}>
        {/* Fullscreen plane */}
        <mesh>
          <planeGeometry args={[2, 2]} />
          {/* @ts-expect-error - custom shader material props provided above */}
          <PixelBlastMaterial {...props} />
        </mesh>
      </Canvas>
    </div>
  )
}
