"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@supabase/ssr"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"

export function SignOutButton({ className }: { className?: string }) {
  const router = useRouter()
  const supabase = React.useMemo(
    () => createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!),
    [],
  )

  const onSignOut = async () => {
    try {
      await supabase.auth.signOut()
    } finally {
      router.push("/sign-in")
    }
  }

  return (
    <Button onClick={onSignOut} variant="destructive" className={className + " gap-2"}>
      <LogOut className="size-4" />
      Logout
    </Button>
  )
}
